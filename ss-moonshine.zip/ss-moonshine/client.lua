local QBCore = exports['qb-core']:GetCoreObject()

local Tasking = false
local StartAppleFarm = false
local random = 0
local PickedApples = 0
local blip = 0
local ShineTimer = Config.ShineTimer
local LoadIngredients = false
local ShineStarted = false
local FinishedShine = false
local ShineMaking = false
local MashMaking = false

local applelocations = {
	[1] = {["x"] = 378.37,["y"] = 6506.16,["z"] = 27.96},
	[2] = {["x"] = 348.0,["y"] = 6506.08,["z"] = 28.8},
	[3] = {["x"] = 321.41,["y"] = 6505.8,["z"] = 29.24},
	[4] = {["x"] = 281.83,["y"] = 6507.27,["z"] = 30.14},
	[5] = {["x"] = 256.04,["y"] = 6504.65,["z"] = 30.87},
	[6] = {["x"] = 227.97,["y"] = 6502.35,["z"] = 31.31},
	[7] = {["x"] = 201.65,["y"] = 6498.16,["z"] = 31.49},
	[8] = {["x"] = 185.09,["y"] = 6498.93,["z"] = 31.54},
	[9] = {["x"] = 199.46,["y"] = 6509.36,["z"] = 31.51},
	[10] = {["x"] = 234.41,["y"] = 6513.25,["z"] = 31.24},
	[11] = {["x"] = 272.42,["y"] = 6519.87,["z"] = 30.44},
	[12] = {["x"] = 261.48,["y"] = 6528.53,["z"] = 30.74},
	[13] = {["x"] = 233.3,["y"] = 6525.43,["z"] = 31.25},
	[14] = {["x"] = 330.34,["y"] = 6518.31,["z"] = 28.95},
	[15] = {["x"] = 347.28,["y"] = 6518.06,["z"] = 28.81},
	[16] = {["x"] = 369.93,["y"] = 6518.18,["z"] = 28.38},
	[17] = {["x"] = 369.36,["y"] = 6532.3,["z"] = 28.36},
	[18] = {["x"] = 353.35,["y"] = 6531.41,["z"] = 28.35},
	[19] = {["x"] = 338.65,["y"] = 6531.77,["z"] = 28.56},
	[20] = {["x"] = 321.9,["y"] = 6531.75,["z"] = 29.14},
}

DrawText3Ds = function(x, y, z, text)
	SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(true)
    AddTextComponentString(text)
    SetDrawOrigin(x,y,z, 0)
    DrawText(0.0, 0.0)
    local factor = (string.len(text)) / 370
    DrawRect(0.0, 0.0+0.0125, 0.017+ factor, 0.03, 0, 0, 0, 75)
    ClearDrawOrigin()
end

CreateThread(function()
	while true do
		local ped = PlayerPedId()
		local pos = GetEntityCoords(ped)
		Orchard = false
		local nearlocation = #(pos - vector3(Config.Moonshine["start"].coords.x, Config.Moonshine["start"].coords.y, Config.Moonshine["start"].coords.z))
			if nearlocation <= 15 then
				Orchard = true
				if nearlocation <= 3 then
					if not StartOrchard then
						DrawText3Ds(413.0, 6538.98, 27.74, "[E] Start Picking Apples")
						if IsControlJustReleased(0,38) then
								StartOrchard = true
						end
					end
				end
			end
		if not Orchard then
			Wait(5000)
		end
		Wait(5)
    end
end)

CreateThread(function()
	while true do
		if StartOrchard then
			if Tasking then
				Wait(5000)
			else
				TriggerEvent("ss-moonshine:client:StartOrchard")
				PickedApples = PickedApples + 1
				print(PickedApples)
				if PickedApples == Config.PickAmount then
					TriggerEvent("ss-moonshine:client:StartOrchard")
					Wait(20000)
					StartOrchard = false
					PickedApples = 0
				end
			end
		end
		Wait(5)
	end
end)

RegisterNetEvent('ss-moonshine:client:StartOrchard', function()
	if Tasking then
		return
	end
	random = math.random(1, #applelocations)
	Tasking = true
	CreateBlip()
	while Tasking do
		Wait(5)
		local ped = PlayerPedId()
		local pos = GetEntityCoords(ped)
		local nearpicking = #(pos - vector3(applelocations[random]["x"], applelocations[random]["y"], applelocations[random]["z"]))
		if nearpicking <= 150 then
			DrawMarker(32, applelocations[random]["x"], applelocations[random]["y"], applelocations[random]["z"] + 2.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.4, 1.0, 0.4, 255, 223, 0, 255, true, false, false, false, false, false, false)
			if nearpicking <= 1.5 then
				DrawMarker(2, applelocations[random]["x"], applelocations[random]["y"], applelocations[random]["z"] + 0.2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.4, 0.4, 0.2, 255, 255, 255, 255, 0, 0, 0, 1, 0, 0, 0)
				DrawText3Ds(applelocations[random]["x"], applelocations[random]["y"], applelocations[random]["z"], " Get to pickin them shiners!")
				if not IsPedInAnyVehicle(PlayerPedId()) and IsControlJustReleased(0,38) then
					PickAnim()
					PickProcess()
				end
			end
		end
	end
end)

function PickApples()
	local success = true
	if success then
		TriggerServerEvent("ss-moonshine:server:GetApple")
		Tasking = false
		DeleteBlip()
	end
end

function CreateBlip()
	if Tasking then
		blip = AddBlipForCoord(applelocations[random]["x"],applelocations[random]["y"],applelocations[random]["z"])
	end
    SetBlipSprite(blip, 465)
    SetBlipScale(blip, 1.0)
    SetBlipAsShortRange(blip, false)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Drop Off")
    EndTextCommandSetBlipName(blip)
end

function DeleteBlip()
	if DoesBlipExist(blip) then
		RemoveBlip(blip)
	end
end

function PickProcess()
    QBCore.Functions.Progressbar("", "Picking Apples ..", math.random(6000,8000), false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {}, {}, {}, function() -- Done
        PickApples()
        ClearPedTasks(PlayerPedId())
    end, function() -- Cancel
        ClearPedTasks(PlayerPedId())
        QBCore.Functions.Notify("Process Canceled", "error")
    end)
end

function PickAnim()
    local ped = PlayerPedId()
    LoadAnim('amb@prop_human_bum_bin@idle_a')
    TaskPlayAnim(ped, 'amb@prop_human_bum_bin@idle_a', 'idle_a', 6.0, -6.0, -1, 47, 0, 0, 0, 0)
end

-- Process Apples

CreateThread(function()
	while true do
			local ped = PlayerPedId()
			local pos = GetEntityCoords(ped)
			ShineMaking = false
			local nearlocation = #(pos - vector3(Config.Moonshine["shine"].coords.x, Config.Moonshine["shine"].coords.y, Config.Moonshine["shine"].coords.z))
				if nearlocation <= 15 then
					ShineMaking = true
					if nearlocation <= 3 then
						if not ShineStarted then
							if not LoadIngredients then
								if #(pos - vector3(Config.Moonshine["shine"].coords.x, Config.Moonshine["shine"].coords.y, Config.Moonshine["shine"].coords.z)) < 1 then
									DrawText3Ds(Config.Moonshine["shine"].coords.x, Config.Moonshine["shine"].coords.y,  Config.Moonshine["shine"].coords.z + 0.2, '[E] Load Ingredients')
									if IsControlJustPressed(0, 38) then
											TriggerServerEvent("ss-moonshine:server:LoadIngredients")
									end
								end
							else
								if not FinishedShine then
									if #(pos - vector3(Config.Moonshine["shine"].coords.x, Config.Moonshine["shine"].coords.y, Config.Moonshine["shine"].coords.z)) < 1 then
										DrawText3Ds(Config.Moonshine["shine"].coords.x, Config.Moonshine["shine"].coords.y, Config.Moonshine["shine"].coords.z + 0.2, '[E] Start shineProcess')
										if IsControlJustPressed(0, 38) then
												StartShineProcess()
										end
									end
								else
									if #(pos - vector3(Config.Moonshine["shine"].coords.x, Config.Moonshine["shine"].coords.y, Config.Moonshine["shine"].coords.z)) < 1 then
										DrawText3Ds(Config.Moonshine["shine"].coords.x, Config.Moonshine["shine"].coords.y, Config.Moonshine["shine"].coords.z + 0.2, '[E] Get shine')
										if IsControlJustPressed(0, 38) then
												TriggerServerEvent("ss-moonshine:server:ReceiveMoonshine")
												FinishedShine = false
												LoadIngredients = false
												ShineStarted = false
										end
									end
								end
							end
						else
							DrawText3Ds(Config.Moonshine["shine"].coords.x, Config.Moonshine["shine"].coords.y, Config.Moonshine["shine"].coords.z - 0.4, 'Ready in '..ShineTimer..'s')
						end
					end
				end
			if not ShineMaking then
				Wait(5000)
			end
        Wait(5)
    end
end)

CreateThread(function()
	while true do
		local ped = PlayerPedId()
		local pos = GetEntityCoords(ped)
		MashMaking = false
		local nearlocation = #(pos - vector3(Config.Moonshine["mash"].coords.x, Config.Moonshine["mash"].coords.y, Config.Moonshine["mash"].coords.z))
			if nearlocation <= 15 then
				MashMaking = true
				if nearlocation <= 3 then
					if #(pos - vector3(Config.Moonshine["mash"].coords.x, Config.Moonshine["mash"].coords.y, Config.Moonshine["mash"].coords.z)) < 1 then
						DrawText3Ds(Config.Moonshine["mash"].coords.x, Config.Moonshine["mash"].coords.y,  Config.Moonshine["mash"].coords.z + 0.2, '[E] Make Mash')
						if IsControlJustPressed(0, 38) then
								TriggerServerEvent("ss-moonshine:server:Mash")
						end
					end
				end
			end
		if not MashMaking then
			Wait(5000)
		end
        Wait(5)
    end
end)

RegisterNetEvent('ss-moonshine:client:Mash', function()
	PrepareAnim()
	MashProcess()
end)

RegisterNetEvent('ss-moonshine:client:LoadIngredients', function()
	LoadIngredients = true
end)

function StartShineProcess()
    CreateThread(function()
        ShineStarted = true
        while ShineTimer > 0 do
            ShineTimer = ShineTimer - 1
            Wait(1000)
		end
		ShineStarted = false
		FinishedShine = true
		ShineTimer = Config.ShineTimer
    end)
end

function MashProcess()
    QBCore.Functions.Progressbar("pick_mash", "Processing apples ..", math.random(15000,20000), false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {}, {}, {}, function() -- Done
        TriggerServerEvent("ss-moonshine:server:ReceiveMash")
        ClearPedTasks(PlayerPedId())
    end, function() -- Cancel
        ClearPedTasks(PlayerPedId())
        QBCore.Functions.Notify("Process Canceled", "error")
    end)
end

function PrepareAnim()
    local ped = PlayerPedId()
    LoadAnim('amb@code_human_wander_rain@male_a@base')
    TaskPlayAnim(ped, 'amb@code_human_wander_rain@male_a@base', 'static', 6.0, -6.0, -1, 47, 0, 0, 0, 0)
end

function LoadAnim(dict)
    while not HasAnimDictLoaded(dict) do
        RequestAnimDict(dict)
        Wait(1)
    end
end
