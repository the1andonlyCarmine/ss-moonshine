local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent('ss-moonshine:server:GetApple', function()
    local xPlayer = QBCore.Functions.GetPlayer(tonumber(source))
    xPlayer.Functions.AddItem("apple", Config.AppleAmount)
    TriggerClientEvent('inventory:client:ItemBox', source, QBCore.Shared.Items['apple'], "add")
end)

RegisterNetEvent('ss-moonshine:server:LoadIngredients', function()
	local xPlayer = QBCore.Functions.GetPlayer(tonumber(source))
    local mash = xPlayer.Functions.GetItemByName('mash')
	if xPlayer.PlayerData.items ~= nil then
        if mash ~= nil then
            if mash.amount >= 12 then
                xPlayer.Functions.RemoveItem("mash", 12, false)
                TriggerClientEvent('inventory:client:ItemBox', source, QBCore.Shared.Items['mash'], "remove")
                TriggerClientEvent("ss-moonshine:client:LoadIngredients", source)
            else
                TriggerClientEvent('QBCore:Notify', source, "You do not have the correct items", 'error')
            end
        else
            TriggerClientEvent('QBCore:Notify', source, "You do not have the correct items", 'error')
        end
	else
		TriggerClientEvent('QBCore:Notify', source, "You Have Nothing...", "error")
	end
end)

RegisterNetEvent('ss-moonshine:server:Mash', function()
	local xPlayer = QBCore.Functions.GetPlayer(tonumber(source))
    local apple = xPlayer.Functions.GetItemByName('apple')
	if xPlayer.PlayerData.items ~= nil then
        if apple ~= nil then
            if apple.amount >= 16 then
                xPlayer.Functions.RemoveItem("apple", 16, false)
                TriggerClientEvent('inventory:client:ItemBox', source, QBCore.Shared.Items['apple'], "remove")
                TriggerClientEvent("ss-moonshine:client:Mash", source)
            else
                TriggerClientEvent('QBCore:Notify', source, "You do not have the correct items", 'error')
            end
        else
            TriggerClientEvent('QBCore:Notify', source, "You do not have the correct items", 'error')
        end
	else
		TriggerClientEvent('QBCore:Notify', source, "You Have Nothing...", "error")
	end
end)

RegisterNetEvent('ss-moonshine:server:ReceiveMoonshine', function()
	local xPlayer = QBCore.Functions.GetPlayer(tonumber(source))
	xPlayer.Functions.AddItem("moonshine", Config.MoonshineAmount, false)
	TriggerClientEvent('inventory:client:ItemBox', source, QBCore.Shared.Items['moonshine'], "add")
end)

RegisterNetEvent('ss-moonshine:server:ReceiveMash', function()
	local xPlayer = QBCore.Functions.GetPlayer(tonumber(source))
	xPlayer.Functions.AddItem("mash", Config.MashAmount, false)
	TriggerClientEvent('inventory:client:ItemBox', source, QBCore.Shared.Items['mash'], "add")
end)

