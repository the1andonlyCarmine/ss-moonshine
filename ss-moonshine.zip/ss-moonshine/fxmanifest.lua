--SoloSquadScripts
fx_version 'cerulean'
game 'gta5'

description 'ss-moonshine'
version '1.2.0'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'

lua54 'yes'