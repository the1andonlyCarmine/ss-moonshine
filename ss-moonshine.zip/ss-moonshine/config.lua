Config = {}

Config.Moonshine = {
	["start"] ={
		coords = vector3(412.98, 6539.03, 27.73),
	},
	["shine"] ={
		coords = vector3(-1001.32, 4847.43, 275.01),
	},
	["mash"] ={
		coords = vector3(2193.9, 5594.44, 53.76),
	}
}

Config.PickAmount = math.random(4, 8)

Config.AppleAmount = math.random(10, 20)

Config.MashAmount = math.random(5, 10)

Config.MoonshineAmount = math.random(10, 20)

Config.ShineTimer = 150
